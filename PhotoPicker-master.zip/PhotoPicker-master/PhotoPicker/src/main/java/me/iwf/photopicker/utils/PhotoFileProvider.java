package me.iwf.photopicker.utils;

import android.support.v4.content.FileProvider;

/**
 * Created by Donglu on 2017/6/7.
 */

public class PhotoFileProvider extends FileProvider {
}
